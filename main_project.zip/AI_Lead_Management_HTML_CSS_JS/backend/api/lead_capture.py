
from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter()

class Lead(BaseModel):
    name: str
    email: str
    phone: str

@router.post('/capture')
def capture_lead(lead: Lead):
    return {'message': f'Lead captured: {lead.name}, {lead.email}, {lead.phone}'}
