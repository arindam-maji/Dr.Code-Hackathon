
from fastapi import APIRouter
import numpy as np
from sklearn.ensemble import RandomForestClassifier

router = APIRouter()

class LeadScorer:
    def __init__(self):
        self.model = RandomForestClassifier()

    def predict(self, features):
        return self.model.predict(np.array(features).reshape(1, -1))

lead_scorer = LeadScorer()

@router.post('/score')
def score_lead(features: list):
    score = lead_scorer.predict(features)
    return {'score': int(score[0])}
