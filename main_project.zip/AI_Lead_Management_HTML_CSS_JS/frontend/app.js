
document.addEventListener('DOMContentLoaded', () => {
    const app = document.getElementById('app');
    app.innerHTML = `
        <h2>Lead Capture</h2>
        <form id="lead-form">
            <input type="text" id="name" placeholder="Name" required />
            <input type="email" id="email" placeholder="Email" required />
            <input type="text" id="phone" placeholder="Phone" required />
            <button type="submit">Capture Lead</button>
        </form>
        <div id="response"></div>
    `;

    const form = document.getElementById('lead-form');
    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const phone = document.getElementById('phone').value;

        try {
            const response = await fetch('http://127.0.0.1:8000/leads/capture', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name, email, phone })
            });
            const data = await response.json();
            document.getElementById('response').innerText = data.message;
        } catch (error) {
            document.getElementById('response').innerText = 'Error capturing lead!';
        }
    });
});
