
import React, { useState } from 'react';

const LeadScoring = () => {
    const [features, setFeatures] = useState([]);
    const [score, setScore] = useState(null);

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('http://127.0.0.1:8000/score', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(features),
            });
            const data = await response.json();
            setScore(data.score);
        } catch (error) {
            alert('Error fetching lead score!');
        }
    };

    return (
        <div>
            <h2>Lead Scoring</h2>
            <button onClick={handleSubmit}>Get Lead Score</button>
            {score !== null && <p>Lead Score: {score}</p>}
        </div>
    );
};

export default LeadScoring;
