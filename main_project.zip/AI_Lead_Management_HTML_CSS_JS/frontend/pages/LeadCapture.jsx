
import React, { useState } from 'react';

const LeadCapture = () => {
    const [lead, setLead] = useState({ name: '', email: '', phone: '' });

    const handleChange = (e) => {
        setLead({ ...lead, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await fetch('http://127.0.0.1:8000/leads/capture', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(lead),
            });
            const data = await response.json();
            alert(data.message);
        } catch (error) {
            alert('Error capturing lead!');
        }
    };

    return (
        <div>
            <h2>Lead Capture</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="name" placeholder="Name" onChange={handleChange} />
                <input type="email" name="email" placeholder="Email" onChange={handleChange} />
                <input type="text" name="phone" placeholder="Phone" onChange={handleChange} />
                <button type="submit">Capture Lead</button>
            </form>
        </div>
    );
};

export default LeadCapture;
