
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LeadCapture from './pages/LeadCapture';
import LeadScoring from './pages/LeadScoring';
import Marketing from './pages/Marketing';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<LeadCapture />} />
                <Route path="/scoring" element={<LeadScoring />} />
                <Route path="/marketing" element={<Marketing />} />
            </Routes>
        </Router>
    );
}

export default App;
